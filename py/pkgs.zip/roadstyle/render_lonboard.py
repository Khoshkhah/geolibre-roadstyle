"""Render styled edges with lonboard (deck.gl / WebGL) — fast for large edge sets.

Two PathLayers (casing under, fill over) mirror the folium "geometry sandwich".
"""
from __future__ import annotations

from .config import DEFAULT as CONFIG
from .palettes import DEFAULT_PALETTE
from .style import resolve


def _hex_to_rgb(h, alpha=255):
    if not h:                                     # no color: the theme's fallback casing
        from . import _settings
        h = _settings.theme_value("roads.fallback.casing")
    h = h.lstrip("#")
    return [int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), alpha]


def _arrays(gdf, palette, highway_col, tunnel_col, bridge_col, which):
    """(colors, widths) for one sandwich half — resolved once per DISTINCT style key.

    ``resolve()`` depends only on (highway, tunnel, bridge) for a fixed palette, and a real
    network carries only a handful of distinct combinations (Stockholm county: 44 across
    456k edges) — so resolve each combination once and broadcast by numpy indexing instead
    of calling it per row.
    """
    import numpy as np

    n = len(gdf)
    hw = gdf[highway_col].tolist() if highway_col and highway_col in gdf.columns else [None] * n
    tn = ([_truthy(v) for v in gdf[tunnel_col]]
          if tunnel_col and tunnel_col in gdf.columns else [False] * n)
    br = ([_truthy(v) for v in gdf[bridge_col]]
          if bridge_col and bridge_col in gdf.columns else [False] * n)
    keys = list(zip(hw, tn, br, strict=True))

    lut = {}                                       # key -> (rgba, width)
    for key in set(keys):
        rs = resolve(key[0], palette=palette, tunnel=key[1], bridge=key[2])
        if which == "casing":
            if rs.casing is None or rs.casing_width <= 0:
                lut[key] = ([0, 0, 0, 0], 0.0)     # invisible
            else:
                lut[key] = (_hex_to_rgb(rs.casing, int(255 * rs.casing_opacity)),
                            rs.casing_width)
        else:
            lut[key] = (_hex_to_rgb(rs.fill, int(255 * rs.opacity)), rs.width)

    codes = {k: i for i, k in enumerate(lut)}
    colors_lut = np.array([c for c, _ in lut.values()], dtype="uint8")
    widths_lut = np.array([w for _, w in lut.values()], dtype="float32")
    idx = np.fromiter((codes[k] for k in keys), dtype=np.intp, count=n)
    return colors_lut[idx], widths_lut[idx]


def _truthy(v) -> bool:
    return str(v).strip().lower() in {"yes", "true", "1"} if v is not None else False


def _arrays_from_frame(rf, which):
    """Build (colors, widths) numpy arrays from a ResolvedFrame (the data-driven path).

    Values here can differ per edge (continuous colormaps), so there is no small key space
    to resolve over — instead the hex→RGBA conversion is cached per distinct (colour,
    opacity) pair and written into preallocated arrays. Categorical styling collapses to a
    handful of cache entries; a fully continuous ramp degrades gracefully to one per edge.
    """
    import numpy as np

    n = len(rf)
    colors = np.empty((n, 4), dtype="uint8")
    widths = np.empty(n, dtype="float32")
    cache = {}
    if which == "casing":
        rows = zip(rf.casing, rf.casing_opacity, rf.casing_width, strict=True)
    else:
        rows = zip(rf.fill, rf.opacity, rf.width, strict=True)
    for i, (col, op, w) in enumerate(rows):
        if which == "casing" and (not col or w <= 0):
            colors[i] = 0
            widths[i] = 0.0
            continue
        rgba = cache.get((col, op))
        if rgba is None:
            rgba = cache[(col, op)] = _hex_to_rgb(col, int(255 * op))
        colors[i] = rgba
        widths[i] = w
    return colors, widths


def render(
    gdf,
    palette: str = DEFAULT_PALETTE,
    highway_col: str = "highway",
    tunnel_col: str | None = "tunnel",
    bridge_col: str | None = "bridge",
    basemap: str | None = None,
    styler=None,
    legend: bool = True,            # accepted for API parity; lonboard legend not yet supported
    legend_position: str = "bottomleft",
    api_key: str | None = None,
    **kwargs,
):
    import inspect

    from lonboard import Map, PathLayer

    from .basemaps import get_basemap
    from .render_web import render as _web_render

    # web-only keywords (arrows, view_3d, tiles, street_view, ...) would reach lonboard.Map() and
    # raise; the set comes from the web renderer's signature, so a new web option cannot slip through
    for _k in inspect.signature(_web_render).parameters.keys() - inspect.signature(render).parameters.keys():
        kwargs.pop(_k, None)

    bm = get_basemap(basemap or CONFIG.basemap, api_key=api_key)
    carto_style = None
    try:
        from lonboard.basemap import CartoBasemap
        carto_style = getattr(CartoBasemap, bm.lonboard, None) if bm.lonboard else None
        if carto_style is None:   # osm/satellite have no Carto basemap -> sensible default
            carto_style = CartoBasemap.DarkMatter if bm.is_dark else CartoBasemap.Positron
    except Exception:
        carto_style = None

    g = gdf.to_crs(4326)

    if styler is None:
        tunnel_col = tunnel_col if (tunnel_col and tunnel_col in g.columns) else None
        bridge_col = bridge_col if (bridge_col and bridge_col in g.columns) else None
        c_col, c_w = _arrays(g, palette, highway_col, tunnel_col, bridge_col, "casing")
        f_col, f_w = _arrays(g, palette, highway_col, tunnel_col, bridge_col, "fill")
    else:
        rf = styler.resolve_frame(g)
        c_col, c_w = _arrays_from_frame(rf, "casing")
        f_col, f_w = _arrays_from_frame(rf, "fill")

    casing = PathLayer.from_geopandas(g, get_color=c_col, get_width=c_w,
                                      width_units="pixels", width_min_pixels=0)
    fill = PathLayer.from_geopandas(g, get_color=f_col, get_width=f_w,
                                    width_units="pixels", width_min_pixels=1)
    map_kw = dict(layers=[casing, fill])
    if carto_style is not None:
        map_kw["basemap_style"] = carto_style
    map_kw.update(kwargs)
    return Map(**map_kw)
