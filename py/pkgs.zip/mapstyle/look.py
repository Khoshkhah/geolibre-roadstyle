"""The base-map look for the roadstyle GeoLibre plugin (roadstyle › Open a duckOSM database), made by the page's own code:
roadstyle draws each layer of ``styles/layers.yaml`` as an overlay (``render_web._overlay_layers``), and the values that
layers.js adds on the page (colour and outline by kind, dashes, textures, icons, zoom ranges) come from ``feature_overlays``
through ``export._restyle``, as in ``export_style``. The plugin reads the ``features.*`` tables of the .duckdb itself, so each
layer names its table and has the layer's ``where`` as a filter.

Not in the look: centroid points (the parking "P" of an area), and the level of a point on a road (the page draws a crossing at
its road's level; here the points are over all the roads)."""
import copy
import json
from pathlib import Path

from mapstyle.style import load_style, load_theme

_GEOM = {"polygon": ["Polygon", "MultiPolygon"], "line": ["LineString", "MultiLineString"], "point": ["Point", "MultiPoint"]}


def _where(where):
    """The MapLibre filter for a ``layers.yaml`` ``where``. Only ``kind = '…'`` and ``kind IN (…)`` are known."""
    import re
    if not where:
        return None
    m = re.fullmatch(r"\s*kind\s+IN\s*\((.*)\)\s*", where, re.I)
    if m:
        return ["in", ["get", "kind"], ["literal", re.findall(r"'([^']*)'", m.group(1))]]
    m = re.fullmatch(r"\s*kind\s*=\s*'([^']*)'\s*", where)
    if m:
        return ["==", ["get", "kind"], m.group(1)]
    raise ValueError(f"export_look reads only kind = '…' and kind IN (…) in layers.yaml, not: {where}")


def export_look(path=None, *, theme: str = "osm") -> dict:
    """``{"name", "layers": [...], "tables": {table: {"hover", "popup"}}, "images": {name: data URL}}``, written to ``path`` if given.
    ``layers`` are in the page's draw order; each has ``table`` (its features.* table), ``group`` (its layers.yaml name: one row in
    the app), ``placement`` (``under`` or ``over`` the roads) and ``ticked`` (shown when the page opens)."""
    from roadstyle import _settings
    from roadstyle import render_web as rw

    from mapstyle.export import _restyle
    from mapstyle.map import feature_overlays

    specs = [s for s in load_style("layers")["layers"] if s.get("show", True)]
    names = list(dict.fromkeys(s.get("merge_into") or s["name"] for s in specs))
    overlays, config = feature_overlays({n: {"type": "FeatureCollection", "features": []} for n in names}, None, load_theme(theme)[0])
    layers = []
    for i, (ov, L) in enumerate(zip(overlays, config["layers"], strict=True)):
        ov.visible = True
        st = {"layers": rw._overlay_layers(f"ov{i}", rw._styled(ov), ov.kind)}
        for x in st["layers"]:
            x["source-layer"] = f"ov{i}"               # _restyle finds a layer's overlay by it
        _restyle(st, config)
        for s in specs:                                 # one copy per table that feeds this layer (landcover: land and sites)
            if (s.get("merge_into") or s["name"]) != L["label"] or s.get("centroid"):
                continue                                # a centroid point (an area's "P") is not in the look
            own = ["all", ["in", ["geometry-type"], ["literal", _GEOM[s["kind"]]]], *[f for f in [_where(s.get("where"))] if f]]
            for x in st["layers"]:
                y = {k: copy.deepcopy(v) for k, v in x.items() if k not in ("source", "source-layer", "metadata")}
                y["id"] = f"{s['name']}-{x['id'].split('-', 1)[1]}"
                y["filter"] = ["all", own, y["filter"]] if y.get("filter") else own
                y.update(table=s["table"], group=L["label"], placement=ov.placement, ticked=L["ticked"])
                layers.append(y)
    t = _settings.theme()
    sel, ovc = t["selection"], t["overlays"]
    hover = {"polygon": {"type": "line", "paint": {"line-color": sel["hover"], "line-opacity": sel["opacity"], "line-width": ovc["width"]}},
             "line": {"type": "line", "paint": {"line-color": sel["hover"], "line-opacity": sel["opacity"], "line-width": ovc["width"]}},
             "point": {"type": "circle", "paint": {"circle-color": sel["hover"], "circle-opacity": sel["opacity"], "circle-radius": ovc["radius"]}}}
    popup = load_style("layers")["popup"]
    tables = {}
    for s in specs:
        tb = tables.setdefault(s["table"], {"hover": {"id": "osm_id", "layers": []}, "popup": {"title": "name", "columns": [c for c in popup if c != "name"]}})
        if not any(h["id"] == f"hover-{s['kind']}" for h in tb["hover"]["layers"]):
            tb["hover"]["layers"].append({"id": f"hover-{s['kind']}", "filter": ["in", ["geometry-type"], ["literal", _GEOM[s["kind"]]]], **hover[s["kind"]]})
    look = {"name": f"mapstyle {theme}", "layers": layers, "tables": tables, "images": config["images"]}
    if path is not None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(look, separators=(",", ":")))
    return look
